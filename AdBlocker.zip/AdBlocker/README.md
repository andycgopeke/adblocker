# AdBlocker (Android)

Bloqueador de anuncios por DNS usando VpnService (VPN local, sin servidores externos).

## Compilar
1. Abre la carpeta en Android Studio (Koala o más reciente, JDK 17).
2. Deja que sincronice Gradle (descarga dependencias).
3. Ejecuta en un dispositivo o emulador (Android 8.0+), o Build > Build APK.

## Uso
- Toca el botón central y acepta el permiso de VPN.
- "Actualizar listas" descarga StevenBlack / AdGuard / OISD.
- Registro: toca un dominio para permitirlo o bloquearlo.
- Ajustes: listas, DNS de salida, dominios propios, apps excluidas, inicio automático.

## Compilar sin instalar nada (GitHub Actions)
1. Crea un repositorio en github.com y sube todo el contenido de esta carpeta (incluida `.github`).
2. Ve a la pestaña **Actions** > **Build APK** > **Run workflow**.
3. Al terminar (unos 5 min), abre la ejecución y descarga **AdBlocker-apk** (contiene app-debug.apk).
