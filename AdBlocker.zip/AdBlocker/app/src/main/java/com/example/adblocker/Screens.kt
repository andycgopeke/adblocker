package com.example.adblocker

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

// ---------------------------------------------------------------- Inicio
@Composable
fun HomeScreen(prefs: Prefs, onToggle: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val running by AdBlockState.running.collectAsState()
    val blocked by AdBlockState.blocked.collectAsState()
    val total by AdBlockState.total.collectAsState()
    val size by AdBlockState.listSize.collectAsState()
    var updating by remember { mutableStateOf(false) }
    var last by remember { mutableLongStateOf(prefs.lastUpdate) }
    val pct = if (total > 0) blocked * 100 / total else 0L

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Spacer(Modifier.height(16.dp))
        Text("AdBlocker", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Button(
            onClick = onToggle,
            modifier = Modifier.size(170.dp),
            shape = CircleShape,
            colors = if (running) ButtonDefaults.buttonColors()
            else ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                contentColor = MaterialTheme.colorScheme.onSurfaceVariant
            )
        ) { Text(if (running) "ACTIVO" else "INACTIVO", style = MaterialTheme.typography.titleLarge) }
        Text(
            if (running) "Bloqueando anuncios en todas las apps" else "Toca el botón para activar",
            style = MaterialTheme.typography.bodyLarge
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Bloqueados", blocked.toString(), Modifier.weight(1f))
            StatCard("Consultas", total.toString(), Modifier.weight(1f))
            StatCard("% bloqueado", "$pct%", Modifier.weight(1f))
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Dominios en la lista: $size")
                Text(
                    "Última actualización: " + if (last == 0L) "nunca (lista básica)"
                    else DateFormat.getDateTimeInstance().format(Date(last)),
                    style = MaterialTheme.typography.bodySmall
                )
                Button(
                    enabled = !updating,
                    onClick = {
                        updating = true
                        scope.launch {
                            val ok = Blocklist.update(ctx, prefs)
                            last = prefs.lastUpdate
                            updating = false
                            Toast.makeText(
                                ctx,
                                if (ok > 0) "Listas actualizadas ($ok)" else "No se pudo descargar. Revisa tu conexión.",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                ) { Text(if (updating) "Descargando…" else "Actualizar listas") }
            }
        }
        TextButton(onClick = { AdBlockState.reset(prefs) }) { Text("Reiniciar estadísticas") }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier) {
    Card(modifier) {
        Column(Modifier.padding(12.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(title, style = MaterialTheme.typography.labelSmall)
        }
    }
}

// ---------------------------------------------------------------- Registro
@Composable
fun LogScreen(prefs: Prefs) {
    val ctx = LocalContext.current
    val log by AdBlockState.log.collectAsState()
    val fmt = remember { DateFormat.getTimeInstance() }
    Column(Modifier.fillMaxSize()) {
        Text("Registro de consultas", Modifier.padding(16.dp), style = MaterialTheme.typography.titleLarge)
        Text(
            "Toca un dominio bloqueado para permitirlo, o uno permitido para bloquearlo.",
            Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.bodySmall
        )
        if (log.isEmpty()) {
            Text("Sin actividad todavía. Activa la protección.", Modifier.padding(16.dp))
        }
        LazyColumn {
            items(log) { e ->
                ListItem(
                    modifier = Modifier.clickable {
                        if (e.blocked) {
                            prefs.whitelist = prefs.whitelist + e.domain
                            Toast.makeText(ctx, "Permitido: ${e.domain}", Toast.LENGTH_SHORT).show()
                        } else {
                            prefs.custom = prefs.custom + e.domain
                            prefs.whitelist = prefs.whitelist - e.domain
                            Toast.makeText(ctx, "Bloqueado: ${e.domain}", Toast.LENGTH_SHORT).show()
                        }
                        Blocklist.setUser(prefs)
                    },
                    headlineContent = { Text(e.domain, maxLines = 1) },
                    supportingContent = { Text(fmt.format(Date(e.time))) },
                    trailingContent = {
                        Text(
                            if (e.blocked) "Bloqueado" else "Permitido",
                            color = if (e.blocked) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                        )
                    }
                )
                HorizontalDivider()
            }
        }
    }
}

// ---------------------------------------------------------------- Ajustes
private val upstreams = listOf(
    "Cloudflare (1.1.1.1)" to "1.1.1.1",
    "Google (8.8.8.8)" to "8.8.8.8",
    "Quad9 (9.9.9.9)" to "9.9.9.9",
    "AdGuard (94.140.14.14)" to "94.140.14.14"
)

@Composable
fun SettingsScreen(prefs: Prefs) {
    val ctx = LocalContext.current
    var sources by remember { mutableStateOf(prefs.sources) }
    var upstream by remember { mutableStateOf(prefs.upstream) }
    var auto by remember { mutableStateOf(prefs.autoStart) }
    var dialog by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Ajustes", style = MaterialTheme.typography.headlineSmall)

        Section("Listas de bloqueo")
        Sources.all.forEach { s ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(s.name)
                    Text(s.desc, style = MaterialTheme.typography.bodySmall)
                }
                Switch(checked = s.id in sources, onCheckedChange = { on ->
                    sources = if (on) sources + s.id else sources - s.id
                    prefs.sources = sources
                })
            }
        }
        Text("Tras cambiar las listas, pulsa «Actualizar listas» en Inicio.", style = MaterialTheme.typography.bodySmall)

        Section("Servidor DNS")
        upstreams.forEach { (label, ip) ->
            Row(
                Modifier.fillMaxWidth().clickable { upstream = ip; prefs.upstream = ip },
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(selected = upstream == ip, onClick = { upstream = ip; prefs.upstream = ip })
                Text(label)
            }
        }

        Section("Personalización")
        OutlinedButton(onClick = { dialog = "white" }, modifier = Modifier.fillMaxWidth()) {
            Text("Dominios permitidos (${prefs.whitelist.size})")
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { dialog = "custom" }, modifier = Modifier.fillMaxWidth()) {
            Text("Dominios bloqueados por mí (${prefs.custom.size})")
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { dialog = "apps" }, modifier = Modifier.fillMaxWidth()) {
            Text("Apps excluidas (${prefs.excludedApps.size})")
        }

        Section("Sistema")
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Iniciar al encender el teléfono", Modifier.weight(1f))
            Switch(checked = auto, onCheckedChange = { auto = it; prefs.autoStart = it })
        }
        Spacer(Modifier.height(12.dp))
        Text(
            "Consejo: si Android tiene «DNS privado» en modo estricto, déjalo en Automático " +
                "(Ajustes › Red › DNS privado) para que el bloqueo funcione.",
            style = MaterialTheme.typography.bodySmall
        )
    }

    when (dialog) {
        "white" -> DomainSetDialog("Dominios permitidos", prefs.whitelist,
            { prefs.whitelist = it; Blocklist.setUser(prefs) }) { dialog = null }
        "custom" -> DomainSetDialog("Dominios bloqueados", prefs.custom,
            { prefs.custom = it; Blocklist.setUser(prefs) }) { dialog = null }
        "apps" -> AppsDialog(prefs) { dialog = null; VpnController.reload(ctx) }
    }
}

@Composable
private fun Section(title: String) {
    Spacer(Modifier.height(20.dp))
    Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
    Spacer(Modifier.height(4.dp))
}

@Composable
fun DomainSetDialog(title: String, initial: Set<String>, onChange: (Set<String>) -> Unit, onClose: () -> Unit) {
    var list by remember { mutableStateOf(initial.sorted()) }
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text("Cerrar") } },
        title = { Text(title) },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = text, onValueChange = { text = it }, singleLine = true,
                        placeholder = { Text("ejemplo.com") }, modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = {
                        val d = text.trim().lowercase().removePrefix("https://").removePrefix("http://").substringBefore('/')
                        if (d.contains('.')) {
                            list = (list + d).distinct().sorted()
                            onChange(list.toSet())
                            text = ""
                        }
                    }) { Text("Añadir") }
                }
                LazyColumn(Modifier.heightIn(max = 300.dp)) {
                    items(list) { d ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(d, Modifier.weight(1f))
                            TextButton(onClick = { list = list - d; onChange(list.toSet()) }) { Text("Quitar") }
                        }
                    }
                }
            }
        }
    )
}

@Composable
fun AppsDialog(prefs: Prefs, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<Pair<String, String>>?>(null) }
    var selected by remember { mutableStateOf(prefs.excludedApps) }
    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            val i = android.content.Intent(android.content.Intent.ACTION_MAIN)
                .addCategory(android.content.Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(i, 0)
                .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
                .filter { it.second != ctx.packageName }
                .distinctBy { it.second }
                .sortedBy { it.first.lowercase() }
        }
    }
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = { prefs.excludedApps = selected; onClose() }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancelar") } },
        title = { Text("Apps que NO se filtran") },
        text = {
            val list = apps
            if (list == null) Text("Cargando…")
            else LazyColumn(Modifier.heightIn(max = 400.dp)) {
                items(list) { (label, pkg) ->
                    Row(
                        Modifier.fillMaxWidth().clickable {
                            selected = if (pkg in selected) selected - pkg else selected + pkg
                        },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = pkg in selected, onCheckedChange = {
                            selected = if (it) selected + pkg else selected - pkg
                        })
                        Text(label)
                    }
                }
            }
        }
    )
}
