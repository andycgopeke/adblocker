package com.example.adblocker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = Prefs(ctx)
        // Solo si el permiso de VPN ya fue concedido (prepare == null)
        if (prefs.autoStart && VpnService.prepare(ctx) == null) VpnController.start(ctx)
    }
}
