package com.example.adblocker

import java.io.ByteArrayOutputStream

object Dns {
    class Question(val name: String, val type: Int, val end: Int)

    fun parseQuestion(d: ByteArray): Question? {
        if (d.size < 17) return null
        val qd = ((d[4].toInt() and 0xFF) shl 8) or (d[5].toInt() and 0xFF)
        if (qd != 1) return null
        var pos = 12
        val sb = StringBuilder()
        while (true) {
            if (pos >= d.size) return null
            val len = d[pos].toInt() and 0xFF
            if (len == 0) { pos++; break }
            if (len >= 0xC0 || pos + 1 + len > d.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(d, pos + 1, len, Charsets.ISO_8859_1))
            pos += len + 1
        }
        if (pos + 4 > d.size) return null
        val type = ((d[pos].toInt() and 0xFF) shl 8) or (d[pos + 1].toInt() and 0xFF)
        return Question(sb.toString(), type, pos + 4)
    }

    /** Respuesta falsa: 0.0.0.0 para A, :: para AAAA, vacia para el resto. */
    fun blockedResponse(query: ByteArray, q: Question): ByteArray {
        val answer = q.type == 1 || q.type == 28
        val rdlen = if (q.type == 1) 4 else 16
        val o = ByteArrayOutputStream()
        o.write(query, 0, 2)
        o.write(0x81); o.write(0x80)
        o.write(0); o.write(1)
        o.write(0); o.write(if (answer) 1 else 0)
        o.write(0); o.write(0); o.write(0); o.write(0)
        o.write(query, 12, q.end - 12)
        if (answer) {
            o.write(0xC0); o.write(0x0C)
            o.write(q.type shr 8); o.write(q.type and 0xFF)
            o.write(0); o.write(1)
            o.write(0); o.write(0); o.write(0); o.write(60)
            o.write(0); o.write(rdlen)
            o.write(ByteArray(rdlen))
        }
        return o.toByteArray()
    }

    private fun checksum(b: ByteArray, off: Int, len: Int): Int {
        var sum = 0
        var i = off
        while (i < off + len) {
            sum += ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)
            i += 2
        }
        while (sum shr 16 != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        return sum.inv() and 0xFFFF
    }

    fun wrapUdp(src: ByteArray, dst: ByteArray, sp: Int, dp: Int, payload: ByteArray): ByteArray {
        val total = 28 + payload.size
        val b = ByteArray(total)
        b[0] = 0x45.toByte()
        b[2] = (total shr 8).toByte(); b[3] = total.toByte()
        b[6] = 0x40.toByte()
        b[8] = 64; b[9] = 17
        src.copyInto(b, 12); dst.copyInto(b, 16)
        val c = checksum(b, 0, 20)
        b[10] = (c shr 8).toByte(); b[11] = c.toByte()
        b[20] = (sp shr 8).toByte(); b[21] = sp.toByte()
        b[22] = (dp shr 8).toByte(); b[23] = dp.toByte()
        val ul = 8 + payload.size
        b[24] = (ul shr 8).toByte(); b[25] = ul.toByte()
        payload.copyInto(b, 28)
        return b
    }
}
