package com.example.adblocker

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("adblocker", Context.MODE_PRIVATE)

    var upstream: String
        get() = sp.getString("upstream", "1.1.1.1")!!
        set(v) = sp.edit().putString("upstream", v).apply()
    var autoStart: Boolean
        get() = sp.getBoolean("autoStart", false)
        set(v) = sp.edit().putBoolean("autoStart", v).apply()
    var wasEnabled: Boolean
        get() = sp.getBoolean("wasEnabled", false)
        set(v) = sp.edit().putBoolean("wasEnabled", v).apply()
    var lastUpdate: Long
        get() = sp.getLong("lastUpdate", 0L)
        set(v) = sp.edit().putLong("lastUpdate", v).apply()
    var blockedTotal: Long
        get() = sp.getLong("blockedTotal", 0L)
        set(v) = sp.edit().putLong("blockedTotal", v).apply()
    var queriesTotal: Long
        get() = sp.getLong("queriesTotal", 0L)
        set(v) = sp.edit().putLong("queriesTotal", v).apply()
    var sources: Set<String>
        get() = sp.getStringSet("sources", setOf("steven", "adguard"))!!.toSet()
        set(v) = sp.edit().putStringSet("sources", v).apply()
    var whitelist: Set<String>
        get() = sp.getStringSet("whitelist", emptySet())!!.toSet()
        set(v) = sp.edit().putStringSet("whitelist", v).apply()
    var custom: Set<String>
        get() = sp.getStringSet("custom", emptySet())!!.toSet()
        set(v) = sp.edit().putStringSet("custom", v).apply()
    var excludedApps: Set<String>
        get() = sp.getStringSet("excludedApps", emptySet())!!.toSet()
        set(v) = sp.edit().putStringSet("excludedApps", v).apply()
}
