package com.example.adblocker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.Executors
import kotlin.concurrent.thread

object VpnController {
    fun start(ctx: Context) =
        ContextCompat.startForegroundService(ctx, Intent(ctx, AdBlockVpnService::class.java))

    fun stop(ctx: Context) {
        ctx.startService(Intent(ctx, AdBlockVpnService::class.java).setAction(AdBlockVpnService.ACTION_STOP))
    }

    fun reload(ctx: Context) {
        if (AdBlockState.running.value) start(ctx)
    }
}

class AdBlockVpnService : VpnService() {
    companion object {
        const val ACTION_STOP = "com.example.adblocker.STOP"
        private const val CHANNEL = "adblocker"
        private const val NOTIF_ID = 1
        private const val VPN_ADDR = "10.111.222.1"
        private const val DNS_ADDR = "10.111.222.2"
    }

    private lateinit var prefs: Prefs
    private var tun: ParcelFileDescriptor? = null
    @Volatile private var running = false
    private val pool = Executors.newFixedThreadPool(6)

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        startForeground(NOTIF_ID, buildNotification())
        begin()
        return START_STICKY
    }

    private fun begin() {
        thread(name = "vpn-start") {
            teardown()
            try { Blocklist.load(this, prefs) } catch (_: Exception) {}
            val b = Builder()
                .setSession("AdBlocker")
                .addAddress(VPN_ADDR, 32)
                .addDnsServer(DNS_ADDR)
                .addRoute(DNS_ADDR, 32)
                .setBlocking(true)
            for (pkg in prefs.excludedApps) {
                try { b.addDisallowedApplication(pkg) } catch (_: Exception) {}
            }
            val fd = try { b.establish() } catch (_: Exception) { null }
            if (fd == null) { shutdown(); return@thread }
            tun = fd
            running = true
            prefs.wasEnabled = true
            AdBlockState.running.value = true
            loop(fd)
        }
    }

    private fun loop(fd: ParcelFileDescriptor) {
        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        val buf = ByteArray(32767)
        var counter = 0
        try {
            while (running) {
                val n = input.read(buf)
                if (n < 0) break
                if (n < 28) continue
                handle(buf, n, output)
                if (++counter % 50 == 0) AdBlockState.persist(prefs)
            }
        } catch (_: Exception) {
        }
    }

    private fun handle(p: ByteArray, n: Int, out: FileOutputStream) {
        if ((p[0].toInt() shr 4) != 4) return
        val ihl = (p[0].toInt() and 0x0F) * 4
        if (p[9].toInt() != 17 || n < ihl + 8) return
        val dstPort = ((p[ihl + 2].toInt() and 0xFF) shl 8) or (p[ihl + 3].toInt() and 0xFF)
        if (dstPort != 53) return
        val srcPort = ((p[ihl].toInt() and 0xFF) shl 8) or (p[ihl + 1].toInt() and 0xFF)
        val srcIp = p.copyOfRange(12, 16)
        val dstIp = p.copyOfRange(16, 20)
        val dns = p.copyOfRange(ihl + 8, n)
        val q = Dns.parseQuestion(dns)

        if (q != null && Blocklist.isBlocked(q.name)) {
            AdBlockState.record(q.name, true)
            val resp = Dns.blockedResponse(dns, q)
            write(out, Dns.wrapUdp(dstIp, srcIp, 53, srcPort, resp))
            return
        }
        if (q != null) AdBlockState.record(q.name, false)
        pool.execute {
            try {
                DatagramSocket().use { s ->
                    protect(s)
                    s.soTimeout = 4000
                    val up = InetAddress.getByName(prefs.upstream)
                    s.send(DatagramPacket(dns, dns.size, up, 53))
                    val rb = ByteArray(4096)
                    val rp = DatagramPacket(rb, rb.size)
                    s.receive(rp)
                    val resp = rb.copyOf(rp.length)
                    write(out, Dns.wrapUdp(dstIp, srcIp, 53, srcPort, resp))
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun write(out: FileOutputStream, packet: ByteArray) {
        synchronized(out) {
            try { out.write(packet) } catch (_: Exception) {}
        }
    }

    private fun teardown() {
        running = false
        try { tun?.close() } catch (_: Exception) {}
        tun = null
    }

    private fun shutdown() {
        teardown()
        AdBlockState.persist(prefs)
        prefs.wasEnabled = false
        AdBlockState.running.value = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() {
        shutdown()
        super.onRevoke()
    }

    override fun onDestroy() {
        teardown()
        AdBlockState.running.value = false
        pool.shutdownNow()
        super.onDestroy()
    }

    private fun buildNotification(): android.app.Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Proteccion activa", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, AdBlockVpnService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("AdBlocker activo")
            .setContentText("Bloqueando anuncios en todas las apps")
            .setContentIntent(open)
            .addAction(0, "Detener", stop)
            .setOngoing(true)
            .build()
    }
}
