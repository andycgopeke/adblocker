package com.example.adblocker

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

data class LogEntry(val domain: String, val blocked: Boolean, val time: Long)

object AdBlockState {
    val running = MutableStateFlow(false)
    val blocked = MutableStateFlow(0L)
    val total = MutableStateFlow(0L)
    val log = MutableStateFlow<List<LogEntry>>(emptyList())
    val listSize = MutableStateFlow(0)

    fun restore(p: Prefs) {
        blocked.value = p.blockedTotal
        total.value = p.queriesTotal
    }

    fun persist(p: Prefs) {
        p.blockedTotal = blocked.value
        p.queriesTotal = total.value
    }

    fun reset(p: Prefs) {
        blocked.value = 0; total.value = 0; log.value = emptyList(); persist(p)
    }

    fun record(domain: String, isBlocked: Boolean) {
        total.update { it + 1 }
        if (isBlocked) blocked.update { it + 1 }
        log.update { (listOf(LogEntry(domain, isBlocked, System.currentTimeMillis())) + it).take(150) }
    }
}
