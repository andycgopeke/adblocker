package com.example.adblocker

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class Source(val id: String, val name: String, val desc: String, val url: String)

object Sources {
    val all = listOf(
        Source("steven", "StevenBlack Unified", "Anuncios y malware (hosts)",
            "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts"),
        Source("adguard", "AdGuard DNS filter", "Anuncios y rastreadores",
            "https://adguardteam.github.io/AdGuardSDNSFilter/Filters/filter.txt"),
        Source("oisd", "OISD Small", "Lista compacta, pocos falsos positivos",
            "https://small.oisd.nl/domainswild2")
    )
}

object Blocklist {
    @Volatile private var domains: Set<String> = emptySet()
    @Volatile private var custom: Set<String> = emptySet()
    @Volatile private var white: Set<String> = emptySet()

    fun parseLine(raw: String): String? {
        var l = raw.trim()
        if (l.isEmpty() || l[0] == '#' || l[0] == '!') return null
        val hash = l.indexOf('#')
        if (hash > 0) l = l.substring(0, hash).trim()
        if (l.startsWith("||")) {
            l = l.removePrefix("||")
            val end = l.indexOfFirst { it == '^' || it == '$' || it == '/' }
            if (end >= 0) l = l.substring(0, end)
        } else {
            val parts = l.split(Regex("\\s+"))
            l = when {
                parts.size >= 2 && (parts[0] == "0.0.0.0" || parts[0] == "127.0.0.1") -> parts[1]
                parts.size == 1 -> parts[0]
                else -> return null
            }
        }
        l = l.removePrefix("*.").lowercase().trimEnd('.')
        if (l == "localhost" || !l.contains('.')) return null
        if (!l.all { it.isLetterOrDigit() || it == '-' || it == '.' || it == '_' }) return null
        return l
    }

    fun load(ctx: Context, prefs: Prefs) {
        val set = HashSet<String>(250_000)
        var any = false
        for (s in Sources.all) {
            if (s.id !in prefs.sources) continue
            val f = File(ctx.filesDir, "list_${s.id}.txt")
            if (f.exists()) {
                f.forEachLine { parseLine(it)?.let(set::add) }
                any = true
            }
        }
        if (!any) {
            ctx.assets.open("default_blocklist.txt").bufferedReader()
                .forEachLine { parseLine(it)?.let(set::add) }
        }
        domains = set
        setUser(prefs)
        AdBlockState.listSize.value = set.size
    }

    fun setUser(prefs: Prefs) {
        custom = prefs.custom
        white = prefs.whitelist
    }

    private fun matches(name: String, set: Set<String>): Boolean {
        var x = name
        while (true) {
            if (x in set) return true
            val i = x.indexOf('.')
            if (i < 0) return false
            x = x.substring(i + 1)
        }
    }

    fun isBlocked(raw: String): Boolean {
        val n = raw.lowercase().trimEnd('.')
        if (matches(n, white)) return false
        return matches(n, custom) || matches(n, domains)
    }

    /** Descarga las listas activas. Devuelve cuantas se actualizaron. */
    suspend fun update(ctx: Context, prefs: Prefs): Int = withContext(Dispatchers.IO) {
        var ok = 0
        for (s in Sources.all) {
            if (s.id !in prefs.sources) continue
            try {
                val c = URL(s.url).openConnection() as HttpURLConnection
                c.connectTimeout = 15000
                c.readTimeout = 30000
                val tmp = File(ctx.filesDir, "list_${s.id}.tmp")
                c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                if (tmp.renameTo(File(ctx.filesDir, "list_${s.id}.txt"))) ok++
            } catch (_: Exception) {
            }
        }
        if (ok > 0) {
            prefs.lastUpdate = System.currentTimeMillis()
            load(ctx, prefs)
        }
        ok
    }
}
